package com.juaracoding;

public class Operator {
    public static void main(String[] args) {
        int modulus = 11 % 3; // 11 / 3 = 3
        System.out.println(modulus);
        int grade = 9;
        grade--;
        System.out.println(grade);
        // (5+3)*2 = 16
        int b = 3;
        // b = b + 1;
        b += 1;
        System.out.println(b);
        boolean isResult = 4 < 5; // |>
        System.out.println(isResult);
        // Bitwise
        int hasil = 10 & 12;
        System.out.println(hasil);
    }
}
