package com.juaracoding.sqa;

import com.juaracoding.oop.*;

public class MainApp {
    public static void main(String[] args) {
        Mahasiswa mahasiswaSatu = new Mahasiswa("Putra", "Budi", "SI");
        mahasiswaSatu.viewProfile();
        // instance Karyawan
        Karyawan karyawanSatu = new Karyawan();
        karyawanSatu.setFirstName("Test");
        karyawanSatu.setLastName("Test");
        karyawanSatu.setAge(20);
        karyawanSatu.setSalary(8000);
        System.out.println(karyawanSatu.getFirstName());
        System.out.println(karyawanSatu.getLastName());
        System.out.println(karyawanSatu.getAge());
        System.out.println(karyawanSatu.getSalary());

        // cara panggil polimorp
        BangunDatar kotaSatu = new Kotak(5);
        kotaSatu.gambar();

        // cara panggil inheritance
        Manager karyawanManager = new Manager();
        karyawanManager.setFirstName("Test");
        karyawanManager.setDepartement("Test");

    }
}
