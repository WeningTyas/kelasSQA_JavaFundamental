package com.juaracoding;

import java.util.Scanner;

public class InputArray {
    public static void main(String[] args) {
        int n;
        Scanner sc=new Scanner(System.in);
        System.out.print("Jumlah data yang ingin di input: ");
        n=sc.nextInt();
        int[] array = new int[n];
        System.out.println("Input data usia: ");
        for(int i=0; i<n; i++)
        {
            array[i]=sc.nextInt();
        }
        System.out.println("View data usia: ");
        for (int i=0; i<n; i++)
        {
            System.out.println(array[i]);
        }
    }
}
