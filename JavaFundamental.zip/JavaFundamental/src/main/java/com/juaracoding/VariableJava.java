package com.juaracoding;

public class VariableJava {
    int luas = 100;
    public static void main(String[] args) {
        // JuaraCoding
        /* Satu
         * Dua
         * Tiga */
        System.out.println("Rumus Bangun Ruang");
        System.out.println("Rumus Bangun Datar");
        {
            int nilai = 10;
            if(true){
                System.out.println("IF Statament");
            }
            for (int i = 0; i < 2; i++) {
                System.out.println(i);
                System.out.println(nilai);
            }
        }
        String namaBootcamp, alamat;
        namaBootcamp  = "JuaraCoding";
        alamat = "Jakarta";
        alamat = "Yogyakarta";
        System.out.println(alamat);
        int stok;
        stok = 200;
        System.out.println(stok);
        float grade = 9.5f;
        double saldo = 400000;
        System.out.println(grade);
        System.out.println(saldo);
        char predikat = 'A';
        VariableJava bangunDatar = new VariableJava(); // instance object
        System.out.println(bangunDatar.luas);
        String pathImage = "C:\\Users\\Lenovo\\Pictures\\155894.jpg";
        System.out.println(pathImage);
        boolean isResult = true;
        // Casting / Promotion
        short tinggi = 1000;
        double dataTinggi = tinggi;
        System.out.println(dataTinggi);
        char huruf = 'j';
        long dataHuruf = huruf;
        System.out.println(dataHuruf);
        // Hitung jumlah dari sebuah kata = "BBB" = 6
        long dataLong = 9223372036854775000l;
        int dataInt = (int) dataLong;
        System.out.println(dataInt);
    }
}
