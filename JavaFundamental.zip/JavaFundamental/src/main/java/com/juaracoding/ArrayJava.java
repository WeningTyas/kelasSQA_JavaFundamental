package com.juaracoding;

public class ArrayJava {
    public static void main(String[] args) {
        // String nama1, nama2, nama3, nama4;
        String[] nama = {"Alfrenza", "Andreas", "Asran", "Fikri"};
        System.out.println(nama.length);
        System.out.println(nama[1]);
        System.out.println(nama[2]);
        System.out.println(nama[3]);
        System.out.println(nama[0]);
        for (int i = 0; i < nama.length; i++) {
            System.out.println(nama[i]);
        }
        for (String peserta : nama) {
            System.out.println(peserta);
        }

        System.out.println("--- Cara ke-2 ---");
        String[] peserta = new String[4];
        peserta[0] = "Alfrenza";
        peserta[1] = "Andreas";
//        peserta[2] = "Asran";
//        peserta[3] = "Fikri";
//        // overwritten
//        peserta[4] = "AsranUbah";
        System.out.println(peserta[2]);
        for (int i = 0; i < peserta.length; i++) {
            System.out.println(peserta[i]);
        }
        for (String i : peserta) {
            System.out.println(i);
        }

        Integer[] nilai = new Integer[4];
        nilai[0] = 9;
        nilai[1] = 10;
        for (Integer grade:nilai) {
            System.out.println(grade);
        }

        // tipe data object
        Integer stok = 100;
        System.out.println(stok.toString());

        int [][] angkaKu = {{1,2,3,4},{5,6,7}};
        int x = angkaKu[0][3]; //index baris, index kolom
        System.out.println(x);
        System.out.println(angkaKu.length); // karena 2 baris
        System.out.println(angkaKu[0].length);
        System.out.println(angkaKu[1].length);
        for (int i = 0; i < angkaKu.length; i++) {
            for (int j = 0; j < angkaKu[i].length; j++) {
                System.out.println(angkaKu[i][j]);
            }
        }


    }
}
