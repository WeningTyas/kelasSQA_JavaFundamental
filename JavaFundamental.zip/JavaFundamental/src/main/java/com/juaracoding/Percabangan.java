package com.juaracoding;

public class Percabangan {
    public static void main(String[] args) {

        int angka = 4460;

        if (angka % 2 == 0) { // 0 == 0 (true)
            System.out.println(angka + " adalah bilangan genap");
        } else {
            System.out.println(angka + " adalah bilangan ganjil");
        }

        // if majemuk
        // 91-100 = A, 84-90 = B, 75-83 = C, D
        int nilai = 101;
        if (nilai >= 91 && nilai <= 100) { // true && false = false
            System.out.println("Predikat A");
        } else if (nilai >= 84 && nilai <= 90) {
            System.out.println("Predikat B");
        } else if (nilai >= 75 && nilai <= 83) {
            System.out.println("Predikat C");
        } else if (nilai >= 0 && nilai <= 74) {
            System.out.println("Predikat D");
        } else {
            System.out.println("Nilai tidak terdefinisi");
        }

        // nested if
        int tgl = 19;
        int platNomor = 1236;
        // bisa lewat jalan Sukarno
        // tidak bisa lewat karena tanggal ganjil
        // tidak bisa lewat karena plat nomor ganjil
        // tidak bisa lewat karena tanggal genap
        // tidak bisa lewat karena plat nomor genap
        if (tgl % 2 == 0) {
            if (platNomor % 2 == 0) {
                System.out.println(tgl + " dan " + platNomor + " bisa lewat jalan Sukarno");
            } else {
                System.out.println(tgl + " tidak bisa lewat karena tanggal genap");
                System.out.println(platNomor + " tidak bisa lewat karena plat nomor ganjil");
            }
        } else if (tgl % 2 == 1) {
            if (platNomor % 2 == 1) {
                System.out.println(tgl + " dan " + platNomor + " bisa lewat jalan Sukarno");
            } else {
                System.out.println(tgl + " tidak bisa lewat karena tanggal ganjil");
                System.out.println(platNomor + " tidak bisa lewat karena plat nomor genap");
            }
        }

        // gaji minimal 7jt bayar pajak
        // laki-laki menikah 5%
        // laki-laki belum menikah 10%
        // perempuan menikah 3%
        // perempuan belum menikah 6%
        double gaji = 6000_000;
        char gender = 'P';
        char status = 'M';
        String text = "Perempuan";
        System.out.println(text.equalsIgnoreCase("perempuan"));
        if (gaji >= 7000_000) {
            System.out.println("Wajib pajak");
        } else {
            System.out.println("Tidak wajib pajak");
        }
        if (text.equalsIgnoreCase("perempuan")) {
            System.out.println("Text Perempuan");
        }

        int menu = 1;
        switch (menu) {
            case 1:
                System.out.println("File");
                break;
            case 2:
                System.out.println("Edit");
                break;
            case 3:
                System.out.println("View");
                break;
            default:
                System.out.println("Nilai tidak didefinisikan");
        }

    }
}
