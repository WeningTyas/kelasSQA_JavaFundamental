package com.juaracoding.oop;

public class Manager extends Karyawan {
    private String departement;

    public String getDepartement() {
        return departement;
    }

    public void setDepartement(String departement) {
        this.departement = departement;
    }
}
