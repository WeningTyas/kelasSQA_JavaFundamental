package com.juaracoding.oop;

public class Calculator {
    int sum(int a, int b){
        return a+b;
    }

    double sum(double a, double b){
        return a+b;
    }
}
