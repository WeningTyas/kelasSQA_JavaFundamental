package com.juaracoding.oop;

public class Segitiga extends BangunDatar {
    @Override
    public void gambar() {
        for (int i = 1; i <= 5; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
