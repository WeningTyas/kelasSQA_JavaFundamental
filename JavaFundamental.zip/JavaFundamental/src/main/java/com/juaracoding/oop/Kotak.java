package com.juaracoding.oop;

import java.util.Date;
import java.util.Scanner;

public class Kotak extends BangunDatar {
    // State
    double sisi;

    public Kotak(double sisi){ // Constructor
        // keyword this
        this.sisi = sisi;
    }

    // Behavior (Method)
    public double luas(){
        return sisi * sisi;
    }

    @Override
    public void gambar() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) { // eksekusi sampai kondisi false
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        // Constructor = Special Method
        Date date = new Date(20000);
        System.out.println(date);

        Scanner input = new Scanner(System.in);
        System.out.print("Masukan sisi = ");
        double sisi = input.nextDouble();

        // instance object
        Kotak kotak = new Kotak(sisi);
        System.out.println("Luas Kotak = "+kotak.luas());

        // Blok dulu , ctrl + shift + alt + a
        System.out.print("Input Day = ");
        String inputDay = input.next();
        System.out.println(day(inputDay));

    }

    static String day(String result){
        return result;
    }
}
