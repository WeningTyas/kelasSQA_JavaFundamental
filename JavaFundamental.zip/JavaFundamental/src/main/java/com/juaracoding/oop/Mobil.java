package com.juaracoding.oop;

public class Mobil {

}
