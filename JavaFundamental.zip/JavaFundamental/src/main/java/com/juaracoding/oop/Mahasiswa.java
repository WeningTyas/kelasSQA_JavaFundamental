package com.juaracoding.oop;

public class Mahasiswa {
    // firstName, lastName, prodi
    String firstName, lastName, prodi;

    public Mahasiswa(String firstName, String lastName, String prodi){
        this.firstName = firstName;
        this.lastName = lastName;
        this.prodi = prodi;
    }

    public void viewProfile(){
        System.out.println(firstName);
        System.out.println(lastName);
        System.out.println(prodi);
    }
}
