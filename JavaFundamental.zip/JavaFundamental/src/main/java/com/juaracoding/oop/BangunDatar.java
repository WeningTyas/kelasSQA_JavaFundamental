package com.juaracoding.oop;

public class BangunDatar {
    public void gambar(){
        System.out.println("Default");
    }
}
