package com.juaracoding.oop;

public class Karyawan {
    private String firstName, lastName;
    private int age;
    private double salary;

    public String getFirstName() { // encapsulation
        return firstName;
    }

    public void setFirstName(String firstName) { // encapsulation
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
