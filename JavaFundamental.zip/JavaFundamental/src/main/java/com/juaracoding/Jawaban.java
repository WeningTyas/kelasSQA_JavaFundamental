package com.juaracoding;

import static com.juaracoding.MethodJava.penjumlahan;

public class Jawaban {
    public static void main(String[] args) {
        int angkaAkhir = 50;
        int sum = 0;

        for (int i = 1; i <= angkaAkhir; i++) {
            sum += i; // 1+2+3+...+50 // sum = sum + i
        }

        System.out.println(sum);
        System.out.println(penjumlahan(6,12));
    }
}
