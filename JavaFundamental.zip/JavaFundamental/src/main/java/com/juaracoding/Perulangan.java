package com.juaracoding;

public class Perulangan {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) { // 5 < 5 = false
            System.out.println(i);
        }
        System.out.println("-----");
        for (int i = -1; i < 0; i++) { // 0 < 0 = false
            System.out.println(i);
        }
        // 0 2 4
        for (int i = -1; i < 9; i++) {
            i++;
            System.out.print(i+" ");
        }
        System.out.println();
        // ***** 5x (kotak 7x7)
        int sisi = 5;
        for (int i = 0; i < sisi; i++) {
            for (int j = 0; j < sisi; j++) { // eksekusi sampai kondisi false
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = 1; i <= sisi; i++) {
            for (int j = sisi; j > i; j--) { // 2 > 2 = false
                System.out.print(" ");
            }
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = 1; i <= sisi; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        String password = "jakarta";
        System.out.println(password.length());
        if(password.length() >= 8) {
            System.out.println("Password sesuai");
        } else {
            System.out.println("Password minimal 8 karakter");
        }

        for (int i = 1; i <= 7; i++) {
            for (int j = i; j <= 7; j++) {
                if(j%2 == 1) {
                    System.out.print(j);
                } else {
                    System.out.print("*");
                }
            }
            System.out.println();
        }

    }
}
