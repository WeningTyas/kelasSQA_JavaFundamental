package com.juaracoding;

import java.util.Scanner;

public class CodeRunner {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
//        Nama: Java
//        Usia: 27
//        Nama: Para Juara
//        Usia: 20
        String nama = input.next();
        int usia = input.nextInt();
        System.out.println("Nama: "+nama);
        System.out.println("Usia: "+usia);
    }
}
