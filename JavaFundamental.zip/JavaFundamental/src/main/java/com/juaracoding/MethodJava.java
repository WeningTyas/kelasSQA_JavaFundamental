package com.juaracoding;

import java.util.Arrays;

public class MethodJava {
    public static void main(String[] args) {
        // instance object
        MethodJava draw = new MethodJava();
        draw.kotak(5);
        draw.kotak(7);

        System.out.println(penjumlahan(5,10));

    }

    void kotak(int sisi){
        for (int i = 0; i < sisi; i++) {
            for (int j = 0; j < sisi; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        System.out.println("-----");
    }

    // buatkan fungsi luas kotak = s*s dan luas kubus = 6*(s*s)

    static double penjumlahan(int a, int b){
        return a+b;
    }

    // buatkan function cek password menggunakan java
    // switch
    // 1 = kotak (luas, keliling)
    // 2 = kubus (volume, luas, keliling)
}
